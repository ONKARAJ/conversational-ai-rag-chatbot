<div align="center">

# 🧠 Context-Aware Conversational AI
### Session-Scoped Memory · Retrieval-Augmented Generation · Full-Stack GenAI

[![Python](https://img.shields.io/badge/Python-3.10+-3776AB?logo=python&logoColor=white)](https://www.python.org/)
[![FastAPI](https://img.shields.io/badge/FastAPI-009688?logo=fastapi&logoColor=white)](https://fastapi.tiangolo.com/)
[![LangChain](https://img.shields.io/badge/🦜️🔗-LangChain-1C3C3C)](https://www.langchain.com/)
[![Groq](https://img.shields.io/badge/Groq-LLM%20Inference-F55036)](https://groq.com/)
[![ChromaDB](https://img.shields.io/badge/ChromaDB-Vector%20Store-6E56CF)](https://www.trychroma.com/)
[![React](https://img.shields.io/badge/React-18-61DAFB?logo=react&logoColor=black)](https://react.dev/)
[![Vite](https://img.shields.io/badge/Vite-Frontend%20Tooling-646CFF?logo=vite&logoColor=white)](https://vitejs.dev/)
[![Tailwind](https://img.shields.io/badge/TailwindCSS-38B2AC?logo=tailwind-css&logoColor=white)](https://tailwindcss.com/)
[![License](https://img.shields.io/badge/License-MIT-yellow.svg)](#license)

A production-style conversational AI platform with **multi-session memory
isolation** and a **RAG-grounded knowledge base** — not a single-turn demo.

[Features](#-features) · [Architecture](#-architecture) · [Quick Start](#-quick-start) · [How It Works](#-how-it-works) · [API](#-api-reference)

</div>

---

## 📌 Overview

Most tutorial chatbots keep one global conversation. This project treats
**conversation memory as a first-class, isolated resource**: every chat gets
its own session ID that scopes both the LangChain message-history object and
the SQL rows behind it, so N concurrent conversations never leak context into
each other.

It began as a LangChain notebook (`ChatBotsHistory.ipynb`) prototyping a
memory-aware chain and a separate RAG pipeline. This repo evolves that
prototype into a decoupled **FastAPI backend + React frontend** application —
see [`docs/NOTEBOOK_ANALYSIS.md`](docs/NOTEBOOK_ANALYSIS.md) for the full
before/after breakdown of what was reused vs. re-engineered.

## ✨ Features

- 🔒 **Isolated session memory** — unique conversation IDs scope both the LangChain `session_id` and the database rows; zero cross-session context leakage
- 📚 **Retrieval-Augmented Generation** — HuggingFace `all-MiniLM-L6-v2` embeddings + persistent ChromaDB similarity search, injected into the prompt as grounded context
- ✂️ **Token-aware context trimming** — `tiktoken`-based message trimming keeps prompts bounded as conversations grow, controlling both cost and latency
- ⚡ **Groq-backed low-latency inference** — `openai/gpt-oss-120b` via the Groq API
- 🗂️ **Full conversation lifecycle** — create, rename, search, delete; auto-generated titles from the first message
- 🎨 **Polished chat UI** — Markdown + GFM rendering, syntax-highlighted code blocks with copy buttons, optimistic message updates, light/dark themes, responsive drawer navigation
- 🛡️ **Typed, safe error handling** — provider failures (auth, rate limits, timeouts, model deprecation) are mapped to structured JSON errors; no stack traces ever reach the client
- 🧩 **Swappable persistence** — SQLite for local development, one connection-string change away from PostgreSQL

## 🏗️ Architecture

```
┌─────────────────────────── React 18 + Vite + Tailwind ───────────────────────────┐
│   Sidebar (conversations)  │  Message Thread  │  Composer                        │
└──────────────────────────────────┬────────────────────────────────────────────────┘
                                    │ REST (JSON) over /api/*
┌───────────────────────────────── FastAPI ─────────────────────────────────────────┐
│  api/conversations.py  ── Pydantic v2 validation, CORS                            │
│         │                                                                         │
│  services/chat.py  ── orchestrates one turn                                       │
│    ├── services/rag.py     top-k similarity search                                │
│    └── services/llm.py     RunnableWithMessageHistory (LCEL)                      │
│              ├── trim_messages          (token-bounded context window)            │
│              ├── ChatPromptTemplate     ({language} + {context} + history)        │
│              └── ChatGroq               (openai/gpt-oss-120b)                     │
│                        │                                                          │
│  services/history.py  ── SQLiteChatMessageHistory (session-scoped)                │
└───────────┬────────────────────────────────────────┬──────────────────────────────┘
            │                                         │
   ┌────────▼─────────┐                     ┌─────────▼──────────┐
   │  SQLite           │                     │  ChromaDB          │
   │  conversations    │                     │  knowledge base     │
   │  + messages       │                     │  + MiniLM vectors   │
   └───────────────────┘                     └─────────────────────┘
```

**Design principles:**
- Clean layering — routes validate & delegate, services hold logic, models describe storage
- Expensive resources (embedding model, vector store, LLM chain) initialized **once** at startup via FastAPI's lifespan handler, not per request
- Blocking LLM calls offloaded to a threadpool so the event loop stays responsive
- One source of truth for conversation history — the same SQL table backs both the REST API and the LangChain memory adapter

## 🚀 Quick Start

```bash
# 1. Clone and configure
git clone <your-repo-url>
cd <repo-name>
cp .env.example .env          # add your GROQ_API_KEY (free at console.groq.com/keys)

# 2. Backend
cd backend
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn main:app --reload --port 8000

# 3. Frontend (new terminal)
cd frontend
npm install
npm run dev
```

Open **http://localhost:5173**. API docs: **http://localhost:8000/docs**.

Verify the backend without spending a single token:
```bash
cd backend && python -m tests.test_smoke
```

> Full setup, troubleshooting, and environment-variable reference:
> [`docs/SETUP.md`](docs/SETUP.md)

## 🔍 How It Works

### Session-scoped memory
Every conversation ID is simultaneously:
1. The SQLite primary key for that conversation
2. The foreign key on every message row
3. The URL path segment (`/api/conversations/{id}/messages`)
4. The LangChain `session_id` passed via `config={"configurable": {"session_id": id}}`

`SQLiteChatMessageHistory` only ever reads rows matching that ID — isolation
is structural, not a runtime check.

### Retrieval-Augmented Generation
```
knowledge_base/*.md → chunked → MiniLM embeddings → ChromaDB (built once at startup)
user question → similarity search (k=3) → formatted into {context} → prompt → Groq
```
Retrieved passages are shown in the UI behind a collapsible "N retrieved
passages" indicator with source attribution and relevance scores.

### Context-window management
`trim_messages(strategy="last", token_counter=tiktoken, start_on="human")`
keeps the prompt within a configurable token budget as a conversation grows —
bounding both cost and the risk of exceeding the model's context window.

## 📡 API Reference

| Method | Endpoint | Description |
|---|---|---|
| `POST` | `/api/conversations` | Create a conversation, returns unique session ID |
| `GET` | `/api/conversations` | List conversations (supports `?search=`) |
| `GET` | `/api/conversations/{id}` | Full transcript for one conversation |
| `PATCH` | `/api/conversations/{id}` | Rename / update settings |
| `DELETE` | `/api/conversations/{id}` | Delete conversation + cascade messages |
| `POST` | `/api/conversations/{id}/messages` | Send a message, receive grounded AI reply |
| `GET` | `/api/health` | Service readiness, model, and RAG status |
| `GET` | `/api/rag/search?q=` | Inspect retriever output directly |

Full request/response schemas: [`docs/SETUP.md#api-reference`](docs/SETUP.md).

## 🧱 Tech Stack

| Layer | Technology |
|---|---|
| LLM Orchestration | LangChain (LCEL, `RunnableWithMessageHistory`) |
| Inference | Groq API (`openai/gpt-oss-120b`) |
| Embeddings | HuggingFace `sentence-transformers` (`all-MiniLM-L6-v2`) |
| Vector Store | ChromaDB (persistent) |
| Backend | FastAPI, Pydantic v2, SQLAlchemy 2.0 |
| Database | SQLite (dev) → PostgreSQL-ready |
| Frontend | React 18, Vite, Tailwind CSS |
| Markdown/Code | `react-markdown`, `remark-gfm`, `react-syntax-highlighter` |

## 📂 Project Structure

```
backend/
├── main.py                    FastAPI app, lifespan, error handlers
├── app/
│   ├── models.py               SQLAlchemy models
│   ├── schemas.py               Pydantic request/response models
│   ├── api/                     REST route handlers
│   ├── core/                    config, database, typed errors
│   └── services/
│       ├── llm.py               model, prompt, trimmer, chain
│       ├── history.py           session-scoped chat history
│       ├── rag.py                embeddings, ChromaDB, retriever
│       └── chat.py               orchestrates one full turn
frontend/
└── src/
    ├── components/               Sidebar, MessageList, Composer, etc.
    ├── hooks/                    useConversations, useThread, useHealth
    └── services/api.js           typed API client
docs/
├── NOTEBOOK_ANALYSIS.md          prototype → production breakdown
└── SETUP.md                      detailed setup & troubleshooting
```

## 🗺️ Roadmap

- [ ] Streaming responses (Server-Sent Events)
- [ ] LangGraph checkpointer migration (successor to `RunnableWithMessageHistory`)
- [ ] Multi-user auth
- [ ] Conversation export (Markdown/JSON)
- [ ] PostgreSQL + pgvector deployment guide

## 📄 License

MIT — see [`LICENSE`](LICENSE).

---

<div align="center">
Built by <a href="https://github.com/your-username">Onkar</a> ·
<a href="https://linkedin.com/in/your-profile">LinkedIn</a>
</div>
