🚀 Project: Context-Aware Conversational AI with Session-Scoped Memory & RAG

Built a full-stack, production-style conversational AI system that goes beyond a single-turn chatbot — it maintains isolated, persistent memory across multiple concurrent conversations while grounding responses in a custom knowledge base via Retrieval-Augmented Generation (RAG).

🔧 Tech Stack
• LLM Orchestration: LangChain (LCEL — RunnableWithMessageHistory, RunnablePassthrough)
• Inference: Groq API (openai/gpt-oss-120b) for low-latency LLM inference
• RAG Pipeline: HuggingFace sentence-transformers (all-MiniLM-L6-v2) embeddings + ChromaDB vector store with persistent similarity search
• Backend: FastAPI (async, Pydantic v2 validation, dependency injection, threadpool-offloaded blocking LLM calls)
• Database: SQLAlchemy ORM over SQLite (swappable to PostgreSQL via a single connection string)
• Frontend: React 18 + Vite + Tailwind CSS — a ChatGPT-style SPA with Markdown/GFM rendering, syntax-highlighted code blocks, and optimistic UI updates
• Architecture: Clean separation of concerns across API, service, and data layers; typed error handling; startup-time singleton initialization for embedding models and vector stores to avoid per-request latency overhead

💡 Key Engineering Challenges Solved
• Session Isolation: Each conversation is assigned a unique session ID that scopes both the LangChain message-history object and the underlying SQL rows — guaranteeing zero context leakage between concurrent chat sessions.
• Context-Window Management: Implemented token-aware message trimming (tiktoken-based counting) to bound prompt size as conversations grow, preventing runaway latency/cost and context-window overflows.
• Grounded Generation: Retrieved passages are injected into the prompt as a dynamic context block, with the model instructed to cite sources when the knowledge base is relevant and fall back to parametric knowledge otherwise.
• Resilience: Typed exception hierarchy translates provider-level failures (auth errors, rate limits, timeouts, model deprecation) into structured, user-safe API responses — no raw stack traces ever reach the client.

This project demonstrates end-to-end GenAI application development — from LLM orchestration and vector search to REST API design and modern frontend engineering — the kind of full-stack AI systems work increasingly expected in SDE and ML Engineering roles.

#GenerativeAI #LangChain #RAG #LLM #FastAPI #React #FullStackDevelopment #MachineLearning #VectorDatabase #SoftwareEngineering
